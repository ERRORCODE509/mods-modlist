# makeshift_mininuke
The science checks out, I see nothing wrong here.
