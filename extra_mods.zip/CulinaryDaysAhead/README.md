# Culinary Days Ahead

## Recipes

- ketchup soup
- hotdog soup
- glassed eggs
- Omelettes / -Deluxe
- Fruity French toast
- Garlic bread
