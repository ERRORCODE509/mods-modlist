# ***consume_the_nut***
## *Giving you a use for that half-ton of pine nuts.*

This mod is the fourth entry into the _nut series of mods. It adds more uses for all of those pine nuts you've managed to collect. Options include pine nut milk, pine nut pulp (the byproduct of pine nut milk), pine nut ambrosia, pine nut butter, and pine nut meal. Provided that I managed to code things right, pine nut butter should be usable as peanut butter in recipes, and pine nut meal should be usable to make flour and bread flour. It case it wasn't already apparent, this mod is meant to be used with my previous pine nut mods.

### **Be Warned: There is an error on world loading that I have yet to narrow down the cause of. Shouldn't effect anything, but wanted to make sure people were aware.**
