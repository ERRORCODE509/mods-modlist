# lube_the_nut
I swear it isn't as bad as it sounds

The mod adds a crafting recipe that allows you to make vegetable cooking oil out of pine nuts. I do plan to eventually make pine nut oil a separate item, but the current implementation of cooking oil in recipes makes that extremely time consuming, so I'll leave it for another day.

Credit to u/Anomma for improving my previous method for covering yourself in oil.
