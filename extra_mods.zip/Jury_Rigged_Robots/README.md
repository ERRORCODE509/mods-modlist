# Jury-Rigged-Robots
The Jury Rigged Robots mod for Cataclysm: Dark Days Ahead.
These are the bug fixed files for the mod. You can just download the master zip and extract to a folder called "Jury_Rigged_Robots" and they should work out of the box for you!
