Thanks for downloading my mod!

This is a fairly huge project aimed at expanding the variety of food and drink options you can find in stores. They're picked clean if you use default settings of 1.0 item spawn rate, but this mod will switch up what few items remain.

Now, instead of just finding a blueberry, or a gallon of fresh milk, or a peanut butter sandwich, you can find steaks, or chow mein, or edamame, or if you're really lucky, some cheesecake or doughnuts!
===================================
INSTALLATION


You'll want to drag this folder to your mods folder located in CDDA/data/mods.

Then simply start a new world with my mod loaded, and enjoy your gourmet delights. Happy hunting!

===================================
ADDING A MOD TO AN EXISTING WORLD

To add my mod to an existing world, just edit the mods.json file in your save folder of choice.

That's located in your root folder i.e. CDDA/save/Quahog/mods.json

Version number: 0.1 [alpha release]