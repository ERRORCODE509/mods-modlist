# Nuclear Grenades Guide

There are two methods to acquire a nuclear grenade, the "I don't care about achievements" easy way and the hard way.

No matter what, just using these as thrown grenades and surviving is almost certainly impossible(see minimum recommended distance below). There is only one "safe" way to use this.

These are the easy way steps, beyond them both ways share the same steps.

## Step 1: Bind the debug menu to a key if you didn't already.

## Step 2: Spawn a nuclear grenade with the debug menu.

## Step 3: Wear ear plugs.

## Step 4: Spawn a RC car and a RC control with the debug menu.

Meanwhile, the hard way is to pray for the RNG and dare to head into military outposts and very dangerous labs in search of one. That's it. Regardless of the chosen method, after that the next steps are the same.

## Step 5: Attach the nuclear grenade to the RC car. Set a frequency to detonate it.

## Step 6: Drive the RC car as far away as possible without losing the signal. From in-game tests the recommended minimum safe distance is 30 tiles. Maybe that is more than the exact minimum safe distance, but better safe than sorry.

## Step 7: Duck and Cover.

## Step 8: Use potassium iodide tablets just in case.

## Step 9: Press the big red button set to the same frequency as the detonator.

## Step 10: Watch the fireworks, hopefully far away enough for this to not become YASD.

## Step 11: If your character is still alive, maybe take some Prussian Blue tablets for precaution.

For the rocket propelled version, aim for targets at about 35 tiles away. They could move in closer while your character is aiming.

PS: Incomplete craters due to reality bubble limitations may happen.