# How to use extra pockets in guns for maximum magazine carry capacity.

First of all, this is not really supported for now in DDA (Jan/2022). It is wonky for magazines, but a lot more convenient for guns that load each round individually like shotguns. The SPAS features straps to the
side of its frame to have spare shells close at hand to load right into the magazine tube, as an example. When it comes to magazines, guns designed in a way that allows spare mags to be fitted within their frame are extremely rare.

The G11 minimod features the capability of the G11 to have extra magazines attached within its frame. Here is how to make use of it.

## Step 1: insert the spares into the non-magazine "pocket"

## Step 2: once the currently loaded mag is empty, drop a loaded mag from the extra "pocket" in the gun on the floor. All of this will happen faster in a prone position, probably.

## Step 3: reload the gun with the magazine just dropped on the floor.

Unfortunately loading directly a full mag from the extra storage to the magazine well in the same gun is not really possible. Still, better than stashing magazines in a less quickly accessible backpack or not having them at all, probably.

## Final Notes

Trying this with a gun that has the same "RELOAD_AND_SHOOT" flag as bows will cause errors. Perhaps one day it will be possible to have "bandoliers" in the shotguns and everything else without complications from existing limits.
Several famous shotguns feature "bandolier" like slots for spare shells to the sides of their frames.