# Release 5 - Jan/2022 for Dark Days Ahead

## JSON fixes and compatibility

- First version compatible with a post pockets DDA version. Tested on build number: 2022-01-02-1804

- Changed item prices in JSON data to "x USD" or "x cent" strings to standardize format with most Cataclysm mods for both DDA and BN.

- Fixed lost "looks_like" tileset settings from multiple instances of "copy_from" over the same items and added a few forgotten ones.

- Fixed small error in the redefinition of sulfuric acid to ammo for the OCGES Biorifle.

- Fixed recipe for hand-loaded 7.62 EC HV not requiring a spare plutonium micro cell.

- Removed barrel and muzzle accessory slots for all multi-barrel weapons that still had one available.

- Removed G11 turret mount option because it's either that or removing the extra "pockets" to attach spare magazines in the gun itself.

- Removed wrongly inherited armor penetration capability in 9mm or higher caliber "miniguns" from the .22 ETC nanogun.

- Made LGW secondary fire control mode irremovable as it should be.

## Balance

- Reduced bashing damage of the CQB and SMG versions of the ER and QR555 by 3 and increased the piercing damage of their integrated bayonet by 3 to make them more useful as guns better optimized for melee combat than most.

- Merged 9mm ETC Desert Eel and conventional 9mm Baby Eel magazines. Both pistols share the same magazine type. Also made the "default" 9mm ETC mags support conventional 9mm, which are now compatible with the 923 machine pistol and its derivatives.

- Reduced the mass of some pocket pistols to make them more convenient for ankle holsters.

- Changed base durability of the OFG16k to 10 and gave the hydrogen filled barrel gunmod a 5% damage chance for every shot, because "durability_modifier" no longer exists. Added "blank" gun_data so this gunmod can be fixed with a firearm repair kit.

- Changed skills in professions and also in crafting recipes to adapt them to DDA skills. Applied Science level 3 is required to craft plasma cartridges for hand-loaded ETC ammo.

- Set nuclear grenade to have exact 94.8 tons explosive power. Recommended minimum safe distance is 30 tiles, it is likely impossible to be thrown that far thus throwing it like a grenade equals YASD. Same thing done to the nuclear 66mm rocket.

- Added longest side values for items where it is relevant for the pockets system, sometimes set at deliberate points to fit with specific types of holsters, or just for fluff in some cases (IE: real length of the H&K G11).

- Changed some volumes to the same measurement of real weapons volume used by DDA to avoid balance discrepancy. May break intended aim speed for some of them unless longest side has a greater influence than volume in DDA for aim speed.

- Changed Rivtech Executive profession sidearm from RM216 SPIW to RM232 IDW with folding wire stock because the former is too long for a XL holster.

## New Content

- Made the tube loader for the .308 SMC craftable with the same requirements as the base game Marlin tube loader recipe.

## Minor Fluff

- Renamed Plutonium Fuel Cells to Plutonium Cells.

- Changed the names of fire modes for some guns to shorter ones for better UI visibility.