# DG_Mods
Collection of Mods for Cataclysm: Dark Days Ahead

To install, place DracoPigMod folder in your /data/mods/ folder.

### What does this mod add/do?
* Allows pigs and piglets to be tamed with cattle fodder.

Changelog:

#### 0.1

- Initial release.
