Thanks for downloading my mod! This one adds a recipe for combining cereal and milk together. It also adds:

A new cereal type [chocolatey], lids for every bowl that didn't already come with one available in a simple crafting recipe, and most excitingly, some bags of nuts you can use to make nut milk that doesn't spoil and can be used to make healthier cereal with. Also, making nut milk will produce a nut paste byproduct that you can use to make protein powder.

===================================
INSTALLATION


You'll want to drag this folder to your mods folder located in CDDA/data/mods.

Then simply start a new world with my mod loaded, and enjoy your gourmet delights. Happy hunting!

===================================
ADDING A MOD TO AN EXISTING WORLD

To add my mod to an existing world, just edit the mods.json file in your save folder of choice.

That's located in your root folder i.e. CDDA/save/Quahog/mods.json

Version number: 0.0 [alpha release]
