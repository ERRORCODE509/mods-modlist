# GunCotton
Adds craftable gun cotton, gun cotton based explosives, and gunpowder.
