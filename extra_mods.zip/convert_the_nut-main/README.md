# convert_the_nut 
## Proving that the pine nut is the superior form of nut.

This mod is the second part of the _nut series of mods. This mod allows you convert various types of nuts into pine nuts, the peak form of nut. Crafting requires a heat source and an item with mana infusion, chem 0, spellcraft 1, and cooking 2, proficiency in alchemy, and 3 hours (there’s a batch craft reduction, of course). Probably should mention that this mod requires Magiclysm, in case that wasn’t already apparent. Everything from peanuts to acorns can be converted to pine nuts (don’t question my decisions, coconuts are definitely a nut and I’m not changing it). Also includes pinecones in the crafting recipe for those that want a more “lore-friendly” way to make pine nuts from pinecones.

You probably have one question: Is this mod balanced?

To that I say, no. No it is not.
