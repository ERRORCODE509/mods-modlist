# hard_start
A _real_ start for _real_ men.
